export function BasicLayout ({ children }) {
  return children
}
