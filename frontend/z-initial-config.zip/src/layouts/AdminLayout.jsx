export function AdminLayout ({ children }) {
  return (
    <div>
      <p>AdminLayout</p>
      {children}
    </div>

  )
}
