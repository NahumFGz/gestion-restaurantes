export function ClientLayout ({ children }) {
  return (
    <div>
      <p>ClientLayout</p>
      {children}
    </div>

  )
}
