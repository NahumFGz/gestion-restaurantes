export function LoginAdmin () {
  return (
    <div>
      <p>Estamos en la LoginAdmin</p>
    </div>

  )
}
