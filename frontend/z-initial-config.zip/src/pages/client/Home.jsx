export function Home () {
  return (
    <div>
      <p>Estamos en la home de client</p>
    </div>

  )
}
