import { Navigation } from './routes'

function App () {
  return (
    <div>
      <Navigation />
    </div>
  )
}

export default App
